
public class TiempoDatos {

		Principal tex=new Principal(); //llamamos a los datos ingresados en la ventada principal

		double datos=tex.total; //lo almacenamos en un double
	double segundo_minutos; //doublde de datos en segundo
	double segundo_horas;
	double segundo_dia;
	double segundo_semana;
	double segundo_mes;
	
	double minuto_milisegundo; //double de datos en milisegundo
	double minuto_segundo;
	double minuto_hora;
	double minuto_dia;
	double minuto_semana;
	double minuto_mes;
	
	double hora_segundo; //double de dato hora
	double hora_minuto;
	double hora_dia;
	double hora_semana;
	double hora_mes;
	
	double dia_segundo; //double dato dia
	double dia_minuto;
	double dia_hora;
	double dia_semana;
	double dia_mes;
	
	
	double semana_segundos; //double dato semana
	double semana_minutos;
	double semana_hora;
	double semana_dias;
	double semana_mes;
	
	
	double mes_segundo;// duoble dato mes
	double mes_minuto;
	double mes_hora;
	double mes_dia;
	double mes_semana;
	
	
	
	
		public TiempoDatos() { 
			//aqui se relizan las conversiones de cada dato
			
			segundo_minutos=datos/60;
		 segundo_horas=datos/3600;
		segundo_dia=datos/86400;
			 segundo_semana=datos/604800;
			segundo_mes=datos/2.628;
			
			
			 minuto_milisegundo=datos*60000;
		 minuto_segundo=datos*60;
			 minuto_hora=datos/60;
			 minuto_dia=datos/1140;
			 minuto_semana=datos/10080;
			 minuto_mes=datos/43800;
			
			
			  hora_segundo=datos*3600;
				 hora_minuto=datos*60;
				 hora_dia=datos/24;
				 hora_semana=datos/168;
				 hora_mes=datos/720;
			 
			 
				 
				  dia_segundo=datos*86400;
					 dia_minuto=datos*1440;
					 dia_hora=datos*24;
					 dia_semana=datos/7;
					 dia_mes=datos/30.417;
						 
				 
					  semana_segundos=datos*604800;
						 semana_minutos=datos*10080;
						 semana_hora=datos*168;
						 semana_dias=datos*7;
						 semana_mes=datos/4.345;
				 
				
						  mes_segundo=datos*2.628;
							 mes_minuto=datos*43800;
							 mes_hora=datos*730;
							 mes_dia=datos*30.417;
							 mes_semana=datos*4.345;
							 
						 
						 
				 }    
				

		 
		
		
		 }
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class  Longitud extends JFrame{
	
	private JPanel panel2;
	private JComboBox listades1;
	private JLabel inicio,etiqueta1,etiqueta2,etiqueta3,etiqueta4,etiqueta5,etiqueta6,etiqueta7;
	private JButton boton1,boton2;
	public Longitud() {
		
		this.setSize(500,500);
		setLocationRelativeTo(null );
		setDefaultCloseOperation(EXIT_ON_CLOSE);	
		setTitle("Longitud");//Establecemos el titulo
		iniciarcomponentes();
		
		
	}
	private void iniciarcomponentes() {
		 panel2 = new JPanel();
		panel2.setLayout(null);
		 this.getContentPane().add(panel2); // en este panel se desarollara todo lo trabajado aqui
		 atras();
		 ColocarListasDes();
		 
		 Principal tex=new Principal();
		 LongitudDatos nums = new LongitudDatos();
		 JLabel datoi = new JLabel();
		 datoi.setText(String.valueOf("Dato Ingresado (metro a) = "  + tex.total)); //llamos los datos del usuario y los ubicamos aqui
		 datoi.setFont(new Font("Arial",Font.BOLD,15));
		 datoi.setBounds(150,00,300,50);
		 panel2.add(datoi);
		  inicio = new JLabel("seleccione la forma de tiempo",SwingConstants.LEFT);
		  inicio.setFont(new Font("Arial",Font.PLAIN,20)); // tipo de forma de la fuente
		  inicio.setOpaque(true);//pintar la Etiqueta 
		  
		inicio.setForeground(Color.gray);//Establecemos el color de la letra
			
			inicio.setBounds(100,00,350,20);
			panel2.add(inicio);
		
		  etiqueta1 = new JLabel(); //etiqueta para llamar un setText
		etiqueta1.setOpaque(true);//pintar la Etiqueta 
			etiqueta1.setBounds(80,140,350,20);
			 etiqueta1.setFont(new Font("Arial",Font.PLAIN,15));
			
			etiqueta1.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
			panel2.add(etiqueta1);
			
			  etiqueta2 = new JLabel(); //etiqueta para llamar un setText
			  etiqueta2.setFont(new Font("Arial",Font.PLAIN,15));
				
				etiqueta2.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
				etiqueta2.setBounds(100,160,350,50);
				panel2.add(etiqueta2);
				
				
				  etiqueta3 = new JLabel(); //etiqueta para llamar un setText
				  etiqueta3.setFont(new Font("Arial",Font.PLAIN,15));
					
					etiqueta3.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
					etiqueta3.setBounds(100,190,350,50);
					panel2.add(etiqueta3);
					
					  etiqueta4 = new JLabel(); //etiqueta para llamar un setText
					  etiqueta4.setFont(new Font("Arial",Font.PLAIN,15));
						
						etiqueta4.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
						etiqueta4.setBounds(100,220,350,50);
						panel2.add(etiqueta4);
						
						
						  etiqueta5 = new JLabel(); //etiqueta para llamar un setText
						  etiqueta5.setFont(new Font("Arial",Font.PLAIN,15));
							
							etiqueta5.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
							etiqueta5.setBounds(100,250,350,50);
							panel2.add(etiqueta5);
							
							  etiqueta6 = new JLabel(); //etiqueta para llamar un setText
							  etiqueta6.setFont(new Font("Arial",Font.PLAIN,15));
								
								etiqueta6.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
								etiqueta6.setBounds(100,280,350,50);
								panel2.add(etiqueta6);
								
								

								  etiqueta7 = new JLabel(); //etiqueta para llamar un setText
								  etiqueta7.setFont(new Font("Arial",Font.PLAIN,15));
									
									etiqueta7.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
									etiqueta7.setBounds(100,310,350,50);
									panel2.add(etiqueta7);
	
							 		
		 
	}

	private void ColocarListasDes() { //creamos un JcomboBox
		String [] lon = {"Metro","kilometro","centimeto","milimetro","milla","pie","yarda","pulgada"}; //se presentan los datos  a desplegar
	
		
		 listades1 = new JComboBox(lon); //hacemos el jcomboBox
		
		listades1.setSelectedItem("Segundos");
		listades1.setBounds(180,45,100,30);
		panel2.add(listades1);
	}
	
	
	
	 private void atras() {

		 boton1= new JButton(); // creamos un boton 
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,15)); //tipo de fuente
		ImageIcon sclim = new ImageIcon("atras2.png");
		boton1.setIcon(new ImageIcon(sclim.getImage().getScaledInstance(32,32, Image.SCALE_SMOOTH))); //arreglamos las medidas de la imagen junto al tama�o del boton
		boton1.setBounds(10,380,32,32);

		panel2.add(boton1);
		 boton1.setEnabled(true);
		 
		 
		 boton2 = new JButton("Calcular"); //creamos un boton que nos calcule los datos
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,15));
		 boton2.setBounds(180,80,100,20);
		 panel2.add(boton2);
		 
		 eventoListener2(); //llamamos al evento escucha , lo unimos a estos botones
		
		 eventoListener(); //llamamos al evento escucha , lo unimos a los botones		 
	 }
	 
	 private void eventoListener() {
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				
				
				Principal a = new Principal(); //hacemos visible la pagina principal del programa
				a.setVisible(true);
			
					
				
				}
				
			};
			boton1.addActionListener(oyente);
		}
	
	 private void eventoListener2() {
			

			ActionListener oyente2 = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				
					LongitudDatos lon= new LongitudDatos(); // hacemos la instancia de los datos convertidos
				int i=listades1.getSelectedIndex(); //cada dato desplegable sera del 0 - 1 por lo tanto  cada numero tendra su accion
				if(i==0) { //este cero  es igual a los datos de metro, se muestran
					
					
					
					etiqueta1.setText(String.valueOf("Metro a centimetro : "  +lon.metro_centimetro));
					
					etiqueta2.setText(String.valueOf("Metro a milimetro : "  +lon.metro_milimetro));
					
					

					etiqueta3.setText(String.valueOf("Metro a milla : "  +lon.metro_milla));
					
					etiqueta4.setText(String.valueOf("Metro a pie : "  +lon.metro_pie));
					

					etiqueta5.setText(String.valueOf("Metro a yarda : "  +lon.metro_yarda));
					
					etiqueta6.setText(String.valueOf("Metro a pulgada  : "  +lon.metro_pulgada));
					
					etiqueta7.setText(String.valueOf("Metro a kilometro  : "  +lon.metro_kilometro));
					
					
				}else if(i==1) { //en la posicion 1 se mostran los datos de kilometro
	               etiqueta1.setText(String.valueOf("kilometro a centimetro : "  +lon.kilometro_centimetro));
					
					etiqueta2.setText(String.valueOf("kilometro a metro : "  +lon.kilometro_metro));
					
					

					etiqueta3.setText(String.valueOf("kilometro a milimetro  : "  +lon.kilmetro_milimetro));
					
					etiqueta4.setText(String.valueOf("kilometro a milla  : "  +lon.kilometro_milla));
					

					etiqueta5.setText(String.valueOf("kilometro a pie  : "  +lon.kilometro_pie));
					
					etiqueta6.setText(String.valueOf("kilometro a yarda : "  +lon.kilometro_yarda));
					etiqueta7.setText(String.valueOf("kilometro a pulgada : "  +lon.kilometro_pulgada));
					
					
					
				}else if(i==2) { //en la posicion dos llamamos a datos centimetros
				
					  etiqueta1.setText(String.valueOf("centimetro a metro : "  +lon.centimetro_metro));
						
						etiqueta2.setText(String.valueOf("centimetro a milimetro  : "  +lon.centimetro_milimetro));
						
						

						etiqueta3.setText(String.valueOf("centimetro a milla : "  +lon.centimetro_milla));
						
						etiqueta4.setText(String.valueOf("centimetro a pie : "  +lon.centimetro_pie));
						

						etiqueta5.setText(String.valueOf("centimetro a yarda  : "  +lon.centimetro_yarda));
						

						etiqueta6.setText(String.valueOf("centimetro a pulgada : "  +lon.centimetro_pulgada));

						etiqueta7.setText(String.valueOf("centimetro a kilometro : "  +lon.centimetro_kilometro));
						
						
				}else if(i==3) { //posicion 3 llamamos a los datos milimetro
					
					  etiqueta1.setText(String.valueOf("milimetro a metro : "  +lon.milimetro_metro));
						
						etiqueta2.setText(String.valueOf("milimetro a centimetro  : "  +lon.milimetro__centimetro));
						
						

						etiqueta3.setText(String.valueOf("milimetro a milla "  +lon.milimetro_milla));
						
						etiqueta4.setText(String.valueOf("milimetro a pie : "  +lon.milimetro_pie));
						

						etiqueta5.setText(String.valueOf("milimetro a yarda  : "  +lon.milimetro_yarda));
						etiqueta6.setText(String.valueOf("milimetro a pulgada  : "  +lon.milimetro_pulgada));
						
						etiqueta7.setText(String.valueOf("milimetro a kilometro  : "  +lon.milimetro_kilometro));
						
					
					
				}else if(i==4) { //posicion cuatro llamamos a los datos de milla
				
					
					  etiqueta1.setText(String.valueOf("milla a metro : "  +lon.milla_metro));
						
						etiqueta2.setText(String.valueOf("milla a milimetro  : "  +lon.milla_milimetro));
						
						

						etiqueta3.setText(String.valueOf("milla a pie "  +lon.milla_pie));
						
						etiqueta4.setText(String.valueOf("milla a yarda : "  +lon.milla_yarda));
						

						etiqueta5.setText(String.valueOf("milla a pulgada  : "  +lon.milla_pulgada));
						etiqueta6.setText(String.valueOf("milla a kilometro  : "  +lon.milla_kilometro));
						
				}else if(i==5) { //posicion 5 llamamos a los datos de pie
					
					 etiqueta1.setText(String.valueOf("pie a metro : "  +lon.pie_metro));
						
						etiqueta2.setText(String.valueOf("pie a milimetro  : "  +lon.pie_milimetro));
						
						

						etiqueta3.setText(String.valueOf("pie a centimetro "  +lon.pie_centimetro));
						
						etiqueta4.setText(String.valueOf("pie a yarda"  +lon.pie_yarda));
						

						etiqueta5.setText(String.valueOf("pie a pulgada  : "  +lon.pie_pulgada));
						etiqueta6.setText(String.valueOf("pie a milla  : "  +lon.pie_milla));
						etiqueta7.setText(String.valueOf("pie a kilometro  : "  +lon.pie_kilometro));
					
				}else if(i==6) { //en la posicion 6 llamamos los datos de yarda
					 etiqueta1.setText(String.valueOf("yarda a metro : "  +lon.yarda_metro));
						
						etiqueta2.setText(String.valueOf("yarda a centimetro  : "  +lon.yarda_centimetro));
						
						

						etiqueta3.setText(String.valueOf("yarda a milimetro "  +lon.yarda_milimetro));
						
						etiqueta4.setText(String.valueOf("yarda a kilometro : "  +lon.yarda_kilometro));
						

						etiqueta5.setText(String.valueOf("yarda a pie  : "  +lon.yarda_pie));
						etiqueta6.setText(String.valueOf("yarda a pulgada  : "  +lon.yarda_pulgada));
						etiqueta7.setText(String.valueOf("yarda a milla  : "  +lon.yarda_milla));
					
					
					
				}else if(i==7) { //en la posicion 7 llamamos los datos de pulgadas
					
					 etiqueta1.setText(String.valueOf("pulgada a metro : "  +lon.pulgada_metro));
						
						etiqueta2.setText(String.valueOf("pulgada a milimetro  : "  +lon.pulgada_milimetro));
						
						

						etiqueta3.setText(String.valueOf("pulgada a centimetro"  +lon.pulgada_centimetro));
						
						etiqueta4.setText(String.valueOf("pulgada a yarda : "  +lon.pulgada_yarda));
						

						etiqueta5.setText(String.valueOf("pulgada a pie  : "  +lon.pulgada_pie));
						etiqueta6.setText(String.valueOf("pulgada a milla  : "  +lon.pulgada_milla));
						etiqueta7.setText(String.valueOf("pulgada a kilometro  : "  +lon.pulgada_kilometro));
				}
				
				
				
				}
				
			};
			boton2.addActionListener(oyente2); //se refiere que el boton ejecutara esta accion 
		}
}
import java.awt.Color
;

import java.awt.Font;
import java.awt.Image;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;



public class Principal extends JFrame{
	
	public static String para; // dato visible en todo el programa
	public	static double total;// dato visible en todo el programa
	private JPanel panel;// dato visible en todo el programa
	public  JTextField Texto;// dato visible en todo el programa
	private JLabel etiqueta4;// dato visible en todo el programa
	private JButton boton1,boton2,boton3,boton4;// dato visible en todo el programa
	public Principal() {
		this.setSize(500,500);//establecemos el tama�o de la ventana
		//setLocation(400,200);//establecemos la posicion de la ventana
		//setBounds(500,95,500,500);
		setLocationRelativeTo(null );//Establecemos la ventana en el centro
		
		
		//this.getContentPane().setBackground(Color.BLUE);//Establecemos el color
		
		iniciarComponetes();
		boton1.setEnabled(false); // se inicializa con un boton apagado
		boton2.setEnabled(false);// se inicializa con un boton apagado
		boton3.setEnabled(false);// se inicializa con un boton apagado
		boton4.setEnabled(false);// se inicializa con un boton apagado
		
	setDefaultCloseOperation(EXIT_ON_CLOSE);	
	setTitle("Conversor");//Establecemos el titulo
		
		
		
	
		
	}
	public void habilitar() {
		
		if(!Texto.getText().isEmpty()) { 
			
			boton2.setEnabled(true); //aqui los boton se encienden dependiedo si hay un dato ingresado
			boton1.setEnabled(true);
			boton3.setEnabled(true);
			boton4.setEnabled(true);
		}else {
			boton2.setEnabled(false);
			boton1.setEnabled(false);
			boton3.setEnabled(false);
			boton4.setEnabled(false);
			etiqueta4.setText("Solo numeros");
		}
	}

	
	public void iniciarComponetes() {
		colocarPanel();   // aqui colocamos visibles la realizacion de funciones de cada elemeneto
		ColocarEtiquetas();
		ColocarBotones();
		
		CajasDeTexto();
		
	 
	}
	
	private void colocarPanel() {
		panel =new JPanel(); //Creacion  de Panel
		panel.setLayout(null);
		//panel.setBackground(Color.GRAY);
		this.getContentPane().add(panel);
	}
	
	private void ColocarEtiquetas() 
{



//JLabel etiqueta = new JLabel("Conversor ",SwingConstants.CENTER);//Etiqueta de texto Y Establecemos la aliniacion hodel texto
		
		//etiqueta.setOpaque(true);//pintar la Etiqueta 
	//	etiqueta.setText("Hola");//Establecemos el texto
		//etiqueta.setForeground(Color.gray);//Establecemos el color de la letra
		//etiqueta.setBackground(Color.WHITE);
		//etiqueta.setBounds(85,25,300,30);
		//etiqueta.setFont(new Font("Eras Bold ITC",Font.BOLD,20));//Establecemos la fuente del  texto
		//panel.add(etiqueta);//Agregamos la etiqueta al panel
		
		
	JLabel etiqueta2 = new JLabel();
		ImageIcon sclim = new ImageIcon("logo1.png");
		etiqueta2.setIcon(new ImageIcon(sclim.getImage().getScaledInstance(350,155, Image.SCALE_SMOOTH))); //etiqueta principal (ubica el logo)
		etiqueta2.setBounds(90,00,350,155);
		panel.add(etiqueta2);
		
	JLabel etiqueta3 = new JLabel("Ingrese su Dato:"); //etiqueta instruccion de ingreso de datos 
		etiqueta3.setBounds(200,110,100,50);
		panel.add(etiqueta3);
		
	
		
	}
	
	public void CajasDeTexto() {

	 Texto = new JTextField(); //esta capta guarda los datos ingresados
		Texto.setBounds(190,150,100,30);
		panel.add(Texto);
		 EventosTeclado();
	}
	
	 private void ColocarBotones() {


		 boton1 = new JButton("Longitud"); //boton que dirige a la ventana longitud
		 boton1.setEnabled(true); //Establecemos el encendido del boton
		 boton1.setMnemonic('a');//Establecemos alt + letra
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,14));
		boton1.setBounds(10,250,100,50);
		panel.add(boton1);
		

		 etiqueta4 = new JLabel(); //etiqueta que pondra un mensaje
		etiqueta4.setBounds(200,350,100,50);
		panel.add(etiqueta4);
		
		
		
		 boton2= new JButton("Tiempo"); // boton que dirige a la ventana de tiempo
		 boton2.setForeground(Color.black);
		 boton2.setFont(new Font("Ebrima",Font.BOLD,15));
		//ImageIcon sclim = new ImageIcon("back.png");
		//boton2.setIcon(new ImageIcon(sclim.getImage().getScaledInstance(72,72, Image.SCALE_SMOOTH)));
		
		boton2.setBounds(130,250,100,50);
		 boton2.setEnabled(true);
		
		panel.add(boton2);
		

		 boton3= new JButton("Masa"); //boton que dirige a la ventana de masa
		 boton3.setForeground(Color.black);
		 boton3.setFont(new Font("Ebrima",Font.BOLD,15));
		boton3.setBounds(250,250,100,50);
		 boton3.setEnabled(true);
		 panel.add(boton3);
		 
		 boton4= new JButton("Temp"); //boton que dirige a la ventana de temperatura
		 boton4.setForeground(Color.black);
		 boton4.setFont(new Font("Ebrima",Font.BOLD,15));
		boton4.setBounds(370,250,100,50);
		 boton4.setEnabled(true);
		 
		 
		panel.add(boton4);
		eventoListener(); //se extrae  la accion de cada botton
		eventoListener2();//se extrae   la accion de cada botton
		eventoListenerma();//se extrae   la accion de cada botton
		eventoListenertem();//se extrae   la accion de cada botton
		}
	 
	 private void eventoListener() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				 total=Double.parseDouble(Texto.getText()); //convertimos de string a double
				
				Longitud a = new Longitud();
				a.setVisible(true);  //hacemos visible la ventana de longitud
			
					
				
				}
				
			};
			boton1.addActionListener(oyente);
		}
	 
	 
	 
	 private void eventoListener2() { //aqui empienza la accion/evento del boton 2
		


			ActionListener oyente2 = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
					 total=Double.parseDouble(Texto.getText()); //se convierte el texto ingresado a un double
					
				Tiempo a = new Tiempo(); //abrimos la ventana de tiempo
				a.setVisible(true);
			
				}
				
			};
			boton2.addActionListener(oyente2);
		}
	 private void eventoListenerma() { //aqui empienza la accion del boton 3
			

			ActionListener oyentema= new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				 total=Double.parseDouble(Texto.getText()); //texto se convierte a un double
				
				masa ma = new masa(); //se abre la ventana de masa
				ma.setVisible(true);
			
					
				
				}
				
			};
			boton3.addActionListener(oyentema);
		}
	 private void eventoListenertem() { //aqui empieza la accion del boton 4
			

			ActionListener oyentetem= new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				 total=Double.parseDouble(Texto.getText());//convertimos el texto a un double
				
				temperatura temp = new temperatura();// se abre la ventana de temperatura
				temp.setVisible(true);
			
					
				
				}
				
			};
			boton4.addActionListener(oyentetem);
		}
private void EventosTeclado() { //aqui empienza la accion del teclado
	
	KeyListener eventos = new KeyListener(){

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			 habilitar(); //habilitamos los botones anteriores que se apagan
			 //habilitar2();
		}

		@Override
		public void keyTyped(KeyEvent e) {
			 
			if(!Character.isDigit(e.getKeyChar())){ //indicamos si la letra del teclado es un digito y de ser asi bloquear la accion
				
				getToolkit().beep();
				e.consume();
				
			}
			
		}
		
	};
		
	
	
	
		
		Texto.addKeyListener(eventos);
	}
	
	
	
	

	
	
	
	
	
	
	
	
}
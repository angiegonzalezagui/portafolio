
public class InicioV {

	public static void main(String[] args) {
		Principal v1 = new Principal();
		v1.setVisible(true); //hace     Visible  la ventana "principal"
		
	
		
		
		
	}
	
	
	

}

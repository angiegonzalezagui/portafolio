
public class masaDatos {

	
	 Principal tex=new Principal();
		
	double datos=tex.total; //llamos a los datos ingresados en la ventana principal
	
	double tonelada_kilogramo; //double que abarca datos de tonelada
	double tonelada_Stone;
	double tonelada_libra;
	double tonelada_onza;
	double tonelada_gramo;
	
	double kilogramo_tonelada; //double que abarca datos de kilogramo
	double kilogramo_stone;
	double kilogramo_libra;
	double kilogramo_onza;
	double kilogramo_gramo;
	
	
	double stone_tonelada; //double que abarca datos de stone
	double stone_libra;
	double stone_kilogramo;
	double stone_onza;
	double stone_gramo;
	
	
	double libra_tonelada;//datos que abarcan datos de libra
	double libra_stone;
	double libra_onza;
	double libra_kilogramo;
	double libra_gramo;
	
	double onza_tonelada; //datos que abarcan datos de onza
	double onza_stone;
	double onza_kilogramo;
	double onza_gramo;
	double onza_libra;
	
	
	double gramo_tonelada; //datos que abarcan datos de gramo
	double gramo_stone;
	double gramo_kilogramo;
	double gramo_libra;
	double gramo_onza;
	
	
	
	public masaDatos() {
	 //aqui se realiza las respectivas conversiones de cada dato y nombre
		 tonelada_kilogramo=datos*1000;
		 tonelada_Stone=datos*157;
		 tonelada_libra=datos*2205;
		 tonelada_onza=datos*35274;
		 tonelada_gramo=datos*1e+6;
		
		  kilogramo_tonelada=datos/1000;
			 kilogramo_stone=datos/6.35;
			 kilogramo_libra=datos*2.205;
			 kilogramo_onza=datos*35.274;
			 kilogramo_gramo=datos*1000;
		
			 
			  stone_tonelada=datos/157;
				 stone_libra=datos*14;
				 stone_kilogramo=datos*6.35;
				 stone_onza=datos*224;
				 stone_gramo=datos*6350;
				
				
				 libra_tonelada=datos/2205;
				 libra_stone=datos/14;
				 libra_onza=datos*16;
				 libra_kilogramo=datos/2.205;
				 libra_gramo=datos*454;
				
				 onza_tonelada=datos/35274;
				 onza_stone=datos/224;
				 onza_kilogramo=datos/35.274;
				 onza_gramo=datos*28.35;
				 onza_libra=datos/16;
				
				
				 gramo_tonelada=datos/1e+6;
				 gramo_stone=datos/6350;
				 gramo_kilogramo=datos/1000;
				 gramo_libra=datos/454;
				 gramo_onza=datos/28.35;	 
			 
			
	}

}


public class TemperaturaDatos {

	 Principal tex=new Principal(); //llamamos los datos ingresados en la ventana principal
		
	double datos=tex.total; //ubicados en un double
	
	
	double gradosCel_fa; //double de  datos celcius
	double gradoscel_kelvin;
	
	
	double gradosfah_cel; //double de datos fahrenheit
	double gradosfah_kelvin;
	
	
	double gradoskelvin_cel; //double de los grados kelvin
	double gradoskelvin_fah;
	public TemperaturaDatos() {
		//aqui se realizan las respectivas conversiones
		
		 gradosCel_fa=datos*1.8+32;
		 gradoscel_kelvin=datos+273.15;
		
		
		 gradosfah_cel=datos-32*0.555;
		 gradosfah_kelvin=datos-32*0.555+273.15;
		
		
		 gradoskelvin_cel=datos-273.15;
		 gradoskelvin_fah=datos-273.15*1.8+32;
	}

}

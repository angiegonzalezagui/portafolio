import java.awt.Color;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class  Tiempo extends JFrame{
	

	private JPanel panel3;
	private JComboBox listades1;
	private JLabel inicio,etiqueta1,etiqueta2,etiqueta3,etiqueta4,etiqueta5,etiqueta6,etiqueta7;
	private JButton boton1,boton2;
	public Tiempo() {
	
		this.setSize(500,500);
		setLocationRelativeTo(null );
		setDefaultCloseOperation(EXIT_ON_CLOSE);	
		setTitle("tiempo");//Establecemos el titulo
		iniciarcomponentes();
		
	}
	private void iniciarcomponentes() {
		panel3 = new JPanel();
		panel3.setLayout(null);
		 this.getContentPane().add(panel3); //en este panel se muestra lo trabajado
		 atras();		 
		 ColocarListasDes();
		 
		 Principal tex=new Principal();
		  inicio = new JLabel("seleccione la forma de tiempo",SwingConstants.LEFT);
		  inicio.setFont(new Font("Arial",Font.PLAIN,20));
		  inicio.setOpaque(true);//pintar la Etiqueta 
		  
		inicio.setForeground(Color.gray);//Establecemos el color de la letra
			
			inicio.setBounds(100,00,350,20);
			panel3.add(inicio);
		
		  etiqueta1 = new JLabel(); //etiqueta que mostrara un setText
		etiqueta1.setOpaque(true);//pintar la Etiqueta 
			etiqueta1.setBounds(80,140,350,20);
			 etiqueta1.setFont(new Font("Arial",Font.PLAIN,15));
			
			etiqueta1.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
			panel3.add(etiqueta1);
			
			  etiqueta2 = new JLabel();//etiqueta que mostrara un setText
			  etiqueta2.setFont(new Font("Arial",Font.PLAIN,15));
				
				etiqueta2.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
				etiqueta2.setBounds(100,160,350,50);
				panel3.add(etiqueta2);
				
				
				  etiqueta3 = new JLabel();//etiqueta que mostrara un setText
				  etiqueta3.setFont(new Font("Arial",Font.PLAIN,15));
					
					etiqueta3.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
					etiqueta3.setBounds(100,190,350,50);
					panel3.add(etiqueta3);
					
					  etiqueta4 = new JLabel();//etiqueta que mostrara un setText
					  etiqueta4.setFont(new Font("Arial",Font.PLAIN,15));
						
						etiqueta4.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
						etiqueta4.setBounds(100,220,350,50);
						panel3.add(etiqueta4);
						
						
						  etiqueta5 = new JLabel();//etiqueta que mostrara un setText
						  etiqueta5.setFont(new Font("Arial",Font.PLAIN,15));
							
							etiqueta5.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
							etiqueta5.setBounds(100,250,350,50);
							panel3.add(etiqueta5);
							
							  etiqueta6 = new JLabel();//etiqueta que mostrara un setText
							  etiqueta6.setFont(new Font("Arial",Font.PLAIN,15));
								
								etiqueta6.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
								etiqueta6.setBounds(100,280,350,50);
								panel3.add(etiqueta6);
	
							 			
								
	}
	
	private void ColocarListasDes() {
		String [] time = {"Segundos","Minutos","Hora","Dia","Semana","Mes"};//datos que se despliegan
	
		
		 listades1 = new JComboBox(time); //JcomboBox
		
		listades1.setSelectedItem("Segundos");
		listades1.setBounds(180,45,100,30);
		panel3.add(listades1);
	}
	
	private void atras() {

		 boton1= new JButton(); //boton que  regresara a  la ventana principal
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,15));
		ImageIcon sclim = new ImageIcon("atras2.png");
		boton1.setIcon(new ImageIcon(sclim.getImage().getScaledInstance(32,32, Image.SCALE_SMOOTH))); //imagen y tama�o
		boton1.setBounds(10,380,32,32);
        panel3.add(boton1);
		 boton1.setEnabled(true);
		
		 eventoListener();		
		 
		 boton2 = new JButton("Calcular"); //calculara los datos ingresados
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,15));
		 boton2.setBounds(180,80,100,20);
		 panel3.add(boton2);
		 
		 eventoListener2();
	 }
	 
	 private void eventoListener() { //hacemos el evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				
				
				Principal a = new Principal(); //hacemos visible la ventana principal
				a.setVisible(true);
			
					
				
				}
				
			};
			boton1.addActionListener(oyente);
		}
	 
	 
	 
	 private void eventoListener2() { //creamos el evento escucha del boton 2 
			

			ActionListener oyente2 = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				
					TiempoDatos time= new TiempoDatos(); //llamamos a las conversiones de tiempo
				int i=listades1.getSelectedIndex(); // volvemos en posicion cada datos desplegable
				if(i==0) { //esta posicion muestra los datos de segundo
					
					
					
					etiqueta1.setText(String.valueOf("segundos a minuto : "  +time.segundo_minutos));
					
					etiqueta2.setText(String.valueOf("segundos a hora : "  +time.segundo_horas));
					
					

					etiqueta3.setText(String.valueOf("segundos a d�a : "  +time.segundo_dia));
					
					etiqueta4.setText(String.valueOf("segundos a semana : "  +time.segundo_semana));
					

					etiqueta5.setText(String.valueOf("segundos a mes : "  +time.segundo_mes));
					
					
					
					
				}else if(i==1) { //esta posion muestra los datos de minuto
	               etiqueta1.setText(String.valueOf("minuto a milisegundo : "  +time.minuto_milisegundo));
					
					etiqueta2.setText(String.valueOf("minuto a segundo  : "  +time.minuto_segundo));
					
					

					etiqueta3.setText(String.valueOf("minuto a hora  : "  +time.minuto_hora));
					
					etiqueta4.setText(String.valueOf("minuto a dia  : "  +time.minuto_dia));
					

					etiqueta5.setText(String.valueOf("minuto a semana  : "  +time.minuto_semana));
					
					etiqueta6.setText(String.valueOf("minuto a mes : "  +time.minuto_mes));
					
					
				}else if(i==2) { //esta posicion muestran los datos de hora
				
					  etiqueta1.setText(String.valueOf("hora a segundo : "  +time.hora_segundo));
						
						etiqueta2.setText(String.valueOf("hora a minuto  : "  +time. hora_minuto));
						
						

						etiqueta3.setText(String.valueOf("hora a dia : "  +time.hora_dia));
						
						etiqueta4.setText(String.valueOf("hora a semana : "  +time.hora_semana));
						

						etiqueta5.setText(String.valueOf("hora a mes  : "  +time.hora_mes));
						
						
				}else if(i==3) { //esta posicion muestra los datos de dia
					
					  etiqueta1.setText(String.valueOf("dia a segundo : "  +time.dia_segundo));
						
						etiqueta2.setText(String.valueOf("dia a minuto  : "  +time.dia_minuto));
						
						

						etiqueta3.setText(String.valueOf("dia a hora "  +time.dia_hora));
						
						etiqueta4.setText(String.valueOf("dia a semana : "  +time.dia_semana));
						

						etiqueta5.setText(String.valueOf("dia a mes  : "  +time.dia_mes));
					
					
				}else if(i==4) { //esta posicion muestra los datos de semana
				
					
					  etiqueta1.setText(String.valueOf("semana a segundo : "  +time.semana_segundos));
						
						etiqueta2.setText(String.valueOf("semana a minuto  : "  +time.semana_minutos));
						
						

						etiqueta3.setText(String.valueOf("semana a hora "  +time.semana_hora));
						
						etiqueta4.setText(String.valueOf("semana a dia : "  +time.semana_dias));
						

						etiqueta5.setText(String.valueOf("semana a mes  : "  +time.semana_mes));
						
				}else if(i==5) { //esta posicion muestra los datos de mes
					
					 etiqueta1.setText(String.valueOf("mes a segundo : "  +time.mes_segundo));
						
						etiqueta2.setText(String.valueOf("mes a minuto  : "  +time. mes_minuto));
						
						

						etiqueta3.setText(String.valueOf("mes a hora "  +time.mes_hora));
						
						etiqueta4.setText(String.valueOf("mes a dia : "  +time.mes_dia));
						

						etiqueta5.setText(String.valueOf("mes a semana  : "  +time.mes_semana));
					
				}
				
				
				
				}
				
			};
			boton2.addActionListener(oyente2);
		}
}
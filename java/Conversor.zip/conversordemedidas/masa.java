import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class masa extends JFrame{

	private JPanel panel2;
	private JComboBox listades1;
	private JButton boton1,boton2;
	private JLabel inicio,etiqueta1,etiqueta2,etiqueta3,etiqueta4,etiqueta5,etiqueta6,etiqueta7;
	
	public masa() {
		
		this.setSize(500,500);
		setLocationRelativeTo(null );
		setDefaultCloseOperation(EXIT_ON_CLOSE);	
		setTitle("Masa");//Establecemos el titulo
		iniciarcomponentes();
		
		
	}
	private void iniciarcomponentes() {
		panel2 = new JPanel();
		panel2.setLayout(null);
		 this.getContentPane().add(panel2); //el panel que contiene lo trabajado aqui
		 atras();
		 ColocarListasDes();
		 Principal tex=new Principal();
			
		 JLabel datoi = new JLabel();
		 datoi.setText(String.valueOf("Dato Ingresado  = "  + tex.total)); //mostramos el valor ingresado en su normalidad
		 datoi.setFont(new Font("Arial",Font.PLAIN,20));
		 datoi.setBounds(150,00,300,50);
		 panel2.add(datoi);

		 inicio = new JLabel("seleccione la forma de tiempo"); //indicaciones del programa
			inicio.setBounds(160,26,350,50);
			panel2.add(inicio);
		
		  etiqueta1 = new JLabel(); //etiqueta que llamara un setText
			etiqueta1.setBounds(100,120,350,50);
			panel2.add(etiqueta1);
			
			  etiqueta2 = new JLabel(); //etiqueta que llamara un setText
				etiqueta2.setBounds(100,140,350,50);
				panel2.add(etiqueta2);
				
				
				  etiqueta3 = new JLabel(); //etiqueta que llamara un setText
					etiqueta3.setBounds(100,160,350,50);
					panel2.add(etiqueta3);
					
					  etiqueta4 = new JLabel(); //etiqueta que llamara un setText
						etiqueta4.setBounds(100,180,350,50);
						panel2.add(etiqueta4);
						
						
						  etiqueta5 = new JLabel(); //etiqueta que llamara un setText
							etiqueta5.setBounds(100,200,350,50);
							panel2.add(etiqueta5);
							
							  etiqueta6 = new JLabel(); //etiqueta que llamara un setText
								etiqueta6.setBounds(100,220,350,50);
								panel2.add(etiqueta6);
		 
	}
	
	private void ColocarListasDes() {
		String [] masa = {"Tonelada","Kilogramo","Stone","Libra","Onza","Gramo"}; //creamos de un JcomboBox de masa, estos son los datos desplegables
	
		
		 listades1 = new JComboBox(masa); //JcomboBox
		
		listades1.setSelectedItem("Tonelada");
		listades1.setBounds(180,70,100,30);
		panel2.add(listades1);
	}
	
	private void atras() { // creacion de botones

		 boton1= new JButton();
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,15));
		ImageIcon sclim = new ImageIcon("atras2.png");
		boton1.setIcon(new ImageIcon(sclim.getImage().getScaledInstance(32,32, Image.SCALE_SMOOTH))); //llamos una imagen con su respectivo tama�o 
        boton1.setBounds(10,380,32,32);

		panel2.add(boton1);
		 boton1.setEnabled(true);
		
		 eventoListener();	
		 
		 
		 
		 
		 boton2 = new JButton("Calcular"); //boton calcular datos ingresados
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,15));
		 boton2.setBounds(180,100,100,20);
		 panel2.add(boton2);
		 eventoListener2();
	 }
	 
	 private void eventoListener() { //evento llamando al boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				
				
				Principal a = new Principal(); //hace visible la ventana principal
				a.setVisible(true);
			
					
				
				}
				
			};
			boton1.addActionListener(oyente);
		}

	 private void eventoListener2() { //hacemos la accion oyente del boton 2
			

			ActionListener oyente2 = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				
					masaDatos masas= new masaDatos(); //instaciamos la base de los datos de MasaDatos
				int i=listades1.getSelectedIndex();
				if(i==0) { //esta posicion hace referencia a las toneladas
					
					
					
					etiqueta1.setText(String.valueOf("tonelada a kilogramo : "  +masas.tonelada_kilogramo));
					
					etiqueta2.setText(String.valueOf("Tonelada a Stone : "  +masas.tonelada_Stone));
					
					

					etiqueta3.setText(String.valueOf("tonelada a libra : "  +masas.tonelada_libra));
					
					etiqueta4.setText(String.valueOf("tonelada a onza : "  +masas.tonelada_onza));
					

					etiqueta5.setText(String.valueOf("tonelada a gramo : "  +masas.tonelada_gramo));
					
					
					
					
				}else if(i==1) { //esta posicion hace referencia a  los kilogramos
	               etiqueta1.setText(String.valueOf("kilogramo a tonelada: "  +masas.kilogramo_tonelada));
					
					etiqueta2.setText(String.valueOf("kilogramo a Stone  : "  +masas.kilogramo_stone));
					
					

					etiqueta3.setText(String.valueOf("kilogramo a libra  : "  +masas.kilogramo_libra));
					
					etiqueta4.setText(String.valueOf("kilogramo a onza  : "  +masas.kilogramo_onza));
					

					etiqueta5.setText(String.valueOf("minuto a semana  : "  +masas.kilogramo_gramo));
					
					
					
				}else if(i==2) { //esta posicion hace referencia a los Stone
				
					  etiqueta1.setText(String.valueOf("Stone a tonelada : "  +masas.stone_tonelada));
						
						etiqueta2.setText(String.valueOf("Stone a libra  : "  +masas.stone_libra));
						
						

						etiqueta3.setText(String.valueOf("Stone a kilogramo : "  +masas.stone_kilogramo));
						
						etiqueta4.setText(String.valueOf("Stone a Onza: "  +masas.stone_onza));
						

						etiqueta5.setText(String.valueOf("Stone a gramo  : "  +masas.stone_gramo));
						
						
				}else if(i==3) { //esta posicion hace referencia las libras
					
					  etiqueta1.setText(String.valueOf("libra a tonelada : "  +masas.libra_tonelada));
						
						etiqueta2.setText(String.valueOf("libra a Stone  : "  +masas.libra_stone));
						
						

						etiqueta3.setText(String.valueOf("Libra a onza "  +masas.libra_onza));
						
						etiqueta4.setText(String.valueOf("Libra a kilogramo : "  +masas.libra_kilogramo));
						

						etiqueta5.setText(String.valueOf("libra a gramo  : "  +masas.libra_gramo));
					
					
				}else if(i==4) { //esta  posicion hace referencia a las onzas
				
					
					  etiqueta1.setText(String.valueOf("onza a tonelada : "  +masas.onza_tonelada));
						
						etiqueta2.setText(String.valueOf("onza a stone  : "  +masas.onza_stone));
						
						

						etiqueta3.setText(String.valueOf("onza a kilgramo : "  +masas.onza_kilogramo));
						
						etiqueta4.setText(String.valueOf("onza a gramo : "  +masas.onza_gramo));
						

						etiqueta5.setText(String.valueOf("onza a libra  : "  +masas.onza_libra));
						
				}else if(i==5) { //esta posicion hace referencia a los gramos
					
					 etiqueta1.setText(String.valueOf("gramo a tonelada : "  +masas.gramo_tonelada));
						
						etiqueta2.setText(String.valueOf("gramo a Stone  : "  +masas.gramo_stone));
						
						

						etiqueta3.setText(String.valueOf("gramo a kilogramo "  +masas.gramo_kilogramo));
						
						etiqueta4.setText(String.valueOf("gramo a libra : "  +masas.gramo_libra));
						

						etiqueta5.setText(String.valueOf("gramo onza : "  +masas.gramo_onza));
					
				}
				
				
				
				}
				
			};
			boton2.addActionListener(oyente2);
		}
}
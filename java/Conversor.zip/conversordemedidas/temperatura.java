 import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class temperatura extends JFrame{
	private JPanel panel2;
	private JComboBox listades1;
	private JButton boton1,boton2;
	private JLabel inicio,etiqueta1,etiqueta2,etiqueta3;
	public temperatura() {
	
		this.setSize(500,500);
		setLocationRelativeTo(null );
		setDefaultCloseOperation(EXIT_ON_CLOSE);	
		setTitle("");//Establecemos el titulo
		iniciarcomponentes();
		
		
	}
	private void iniciarcomponentes() {
		 panel2 = new JPanel();
		panel2.setLayout(null);
		 this.getContentPane().add(panel2); //aqui se encontraran puestos lo trabajado aqui
		 ColocarListasDes();
		 atras();
		 Principal tex=new Principal();
			
		 JLabel datoi = new JLabel();
		 datoi.setText(String.valueOf("Dato Ingresado (Volumen) = "  + tex.total)); //llamos el dato ingresado natural
		 datoi.setFont(new Font("Arial",Font.BOLD,15));
		 datoi.setBounds(70,00,300,50);
		 panel2.add(datoi);

		
		
		  etiqueta1 = new JLabel(); //etiqueta que mostrara un setText
		etiqueta1.setOpaque(true);//pintar la Etiqueta 
			etiqueta1.setBounds(80,140,350,20);
			 etiqueta1.setFont(new Font("Arial",Font.PLAIN,15));
			
			etiqueta1.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
			panel2.add(etiqueta1);
			
			  etiqueta2 = new JLabel();//etiqueta que mostrara un setText
			  etiqueta2.setFont(new Font("Arial",Font.PLAIN,15));
				
				etiqueta2.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
				etiqueta2.setBounds(100,160,350,50);
				panel2.add(etiqueta2);
				
				
				  etiqueta3 = new JLabel();//etiqueta que mostrara un setText
				  etiqueta3.setFont(new Font("Arial",Font.PLAIN,15));
					
					etiqueta3.setForeground(Color.DARK_GRAY);//Establecemos el color de la letra
					etiqueta3.setBounds(100,190,350,50);
					panel2.add(etiqueta3);
		 
		
	}
	
	private void ColocarListasDes() {
		String [] grados = {"celcius","Fahrenheit","Kelvin",}; //hacemos un lista que despliega datos de un JcomboBox
	
		
		 listades1 = new JComboBox(grados); //JcomboBox
		
		listades1.setSelectedItem("celcius");
		listades1.setBounds(180,45,100,30);
		panel2.add(listades1);
	}
	 private void atras() {

		 boton1= new JButton(); //boton que sirve a regresar a la ventana principal
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,15));
		ImageIcon sclim = new ImageIcon("atras2.png");
		boton1.setIcon(new ImageIcon(sclim.getImage().getScaledInstance(32,32, Image.SCALE_SMOOTH))); //imagen, con su tama�o
		boton1.setBounds(10,380,32,32);

		panel2.add(boton1);
		 boton1.setEnabled(true);
		 
		 
		 boton2 = new JButton("Calcular");//este boton calculara los datos ingresados
		 boton1.setForeground(Color.black);
		 boton1.setFont(new Font("Ebrima",Font.BOLD,15));
		 boton2.setBounds(180,80,100,20);
		 panel2.add(boton2);
		 eventoListener2();
		 eventoListener();		 
	 }
	 
	 private void eventoListener() { //este es el evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				
				
				Principal a = new Principal(); //hace visible la ventana  principal
				a.setVisible(true);
			
					
				
				}
				
			};
			boton1.addActionListener(oyente);
		}
	 private void eventoListener2() { //evento del boton 2
			

			ActionListener oyente2 = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				
					TemperaturaDatos tem = new TemperaturaDatos(); //llamamos a los datos de temperatura ya convertidos
				int i=listades1.getSelectedIndex();//muestra de lista desplegable por posicion
				if(i==0) { //esta posicion muestra los grados celcius
					
					
					
					etiqueta1.setText(String.valueOf("celcius a fahrenheit : "  +tem. gradosCel_fa));
					
					etiqueta2.setText(String.valueOf("celcius a kelvin : "  +tem. gradoscel_kelvin));
					
					

					
					
					
					
					
				}else if(i==1) { //esta posicion muestra los datos fahrenheit
	               etiqueta1.setText(String.valueOf("grados fahrenheit a celcius : "  +tem. gradosfah_cel));
					
					etiqueta2.setText(String.valueOf("grados fahrenheit a kelvin  : "  +tem. gradosfah_kelvin));
				
					
				
					
					
				}else if(i==2) { //esta posion muestra los grados kelvin
				
					  etiqueta1.setText(String.valueOf("grados kelvin a celcius : "  +tem. gradoskelvin_cel));
						
						etiqueta2.setText(String.valueOf("grados kelvin a fahrenheit : "  +tem. gradoskelvin_fah));
						
						

					
					
				
						
				
					
				}
				
				
				
				}
				
			};
			boton2.addActionListener(oyente2);
		}
}
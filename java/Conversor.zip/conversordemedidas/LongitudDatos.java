public class LongitudDatos{

	 Principal tex=new Principal(); //llamamos los datos ingresados para conversion
	
	double datos=tex.total; //lo definimos en un double llamado dato
	double metro_centimetro; // creamos  double que convierte el dato a metro
	double metro_milimetro;
	double metro_milla;
	double metro_pie;
	double metro_yarda;
	double metro_pulgada;
	double metro_kilometro;
	
	double kilometro_centimetro; //creamos un double que convierta a kilometro
	double kilometro_metro;
	double kilmetro_milimetro;
	double kilometro_milla;
	double kilometro_pie;
	double kilometro_yarda;
	double kilometro_pulgada;
	
	double centimetro_metro; //creamos un double que convierta a centimetro
	double centimetro_milimetro;
	double centimetro_milla;
	double centimetro_pie;
	double centimetro_yarda;
	double centimetro_pulgada;
	double centimetro_kilometro;
	
	double milimetro_metro; //creamos un double que convierta a milimetro
	double milimetro__centimetro;
	double milimetro_milla;
	double milimetro_pie;
	double milimetro_yarda;
	double milimetro_pulgada;
	double milimetro_kilometro;
	
	
	double milla_metro; //creamos un double que  convierta el dato a milla
	double milla_milimetro;
	double milla_pie;
	double milla_yarda;
	double milla_pulgada;
	double milla_kilometro;
	
	
	
	double pie_metro; //creamos un double que convierta el dato a pie
	double pie_milimetro;
	double pie_centimetro;
	double pie_yarda;
	double pie_pulgada;
	double pie_milla;
	double pie_kilometro;
	 
	double yarda_metro;//creamos un dato que convierta a yarda
	double yarda_centimetro;
	double yarda_milimetro;
	double yarda_pie;
	double yarda_pulgada;
	 double yarda_milla;
	double yarda_kilometro;
	 
	double pulgada_metro; //creamos un dato que convierta a pulgada
	double pulgada_milimetro;
	double pulgada_centimetro;
	double pulgada_yarda;
	double pulgada_pie;
	double pulgada_milla;	
	double  pulgada_kilometro;
	
 public LongitudDatos() {
	  //de este lado hacemos las respectivas conversiones de cada dato seleccionado
	 
	  metro_centimetro=datos*100;
		 metro_milimetro=datos*1000;
		 metro_milla=datos/1609;
		 metro_pie=datos*3.281;
		 metro_yarda=datos*1.094;
		 metro_pulgada=datos*39.37;
		 metro_kilometro=datos/1000;
		 
		  kilometro_centimetro=datos*10000;
			 kilometro_metro=datos*1000;
		 kilmetro_milimetro=datos*1e+6;
			 kilometro_milla=datos/1.609;
			 kilometro_pie=datos*3281;
			 kilometro_yarda=datos*1094;
			 kilometro_pulgada=datos*39370;
	 
		  centimetro_metro=datos/100;
			 centimetro_milimetro=datos*10;
			 centimetro_milla=datos/160934;
			 centimetro_pie=datos/30.48;
			 centimetro_yarda=datos/91.44;
			 centimetro_pulgada=datos/2.54;
			 centimetro_kilometro=datos/10000;
		 
			  milimetro_metro=datos/1000;
				 milimetro__centimetro=datos/10;
				 milimetro_milla=datos/1.609;
				 milimetro_pie=datos/305;
				 milimetro_yarda=datos/914;
				 milimetro_pulgada=datos/25.4;
				milimetro_kilometro=datos/1e+6;
				 
				 
				  milla_metro=datos*1609;
					 milla_milimetro=datos*1.609;
					 milla_pie=datos*5280;
					 milla_yarda=datos*1760;
					 milla_pulgada=datos*63360;
milla_kilometro=datos*1.609;
					 
					  pie_metro=datos/3.211;
						 pie_milimetro=datos*305;
						 pie_centimetro=datos*30.4;
						 pie_yarda=datos/3;
						 pie_pulgada=datos*12;	 
						 pie_milla=datos/5280;
						 pie_kilometro=datos/3281;
						 
						  yarda_metro=datos/1.094;
							 yarda_centimetro=datos*91.44;
							 yarda_milimetro=datos*914;
							 yarda_pie=datos*3;
							 yarda_pulgada=datos*36;
							  yarda_milla=datos/1760;	 
							  yarda_kilometro=datos/1094;
							  

								 pulgada_metro=datos/39.37;
								 pulgada_milimetro=datos*25.4;
								 pulgada_centimetro=datos*2.54;
								 pulgada_yarda=datos/36;
								 pulgada_pie=datos/12;
								 pulgada_milla=datos/63360;	
								 pulgada_kilometro=datos/39370;
 }    
 
 
 
 
}
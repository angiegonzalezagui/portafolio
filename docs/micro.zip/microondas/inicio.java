public class inicio{
	
	
	
	public static void main(String []args) {
		principal v1= new principal();
		v1.setVisible(true);
		
		
		
		
		
	}
}
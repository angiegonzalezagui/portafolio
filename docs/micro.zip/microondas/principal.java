import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;
import java.awt.event.*;

public class principal extends JFrame {
	public static String numero1="";
	public static String cadena;
	public static String numero2="";
	public	static int segundos,minutos;
	public static double e;
	public static int contador=0;
	public static int i,j,k,l;
	public static  boolean bandera=true;
	public static  boolean parar=true;
	private JPanel panel;
	private Timer T,p,f,c;
	private JTextField caja,caja2;
	private JLabel etiqueta1;
	private JButton uno,dos,tres,cuatro,cinco,seis,siete,ocho,nueve,cero,borrar,iniciar,popcorn,cafe,fideos,abierto,cerrar;
	public principal(){
		
		this.setSize(800,400);//establecemos el tama�o
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("WIRPOOL 2.34 ");//Establecemos el titulo de la ventana 
		//setLocation(100,200);//establecemos la posicion inicial de la ventana
		//setBounds(100,200,500,500);// establecemos la posicion inicial y el tama�o de la ventana
		setLocationRelativeTo(null);//establecemos la ventana al centro
		iniciarcomponentes();
	}
	
	
	
	private void iniciarcomponentes() {
		
		
		panel();
		etiquetas();
		botones();
		Times();
		
		
	}
	private void panel() {
		
		 panel = new JPanel(); //creamos el panel
			this.getContentPane().add(panel);//agregamos el panel de la ventana
			
			panel.setBackground(Color.gray);//cambiamos el color
			panel.setLayout(null);
		
	}
	
	private void etiquetas() {
		
		
	
	
		 etiqueta1 = new JLabel(); //etiqueta de texto
		 etiqueta1.setOpaque(true);
		 etiqueta1.setBackground(Color.black);//cambiamos el color
		
		etiqueta1.setBounds(00,00,400,400);
		panel.add(etiqueta1);	
		
		
		 caja = new JTextField(); //etiqueta de texto
		 caja.setOpaque(true);
		caja.setFont(new Font("Eras Bold ITC",Font.PLAIN,15));//Establecemos la fuente del  texto
		caja.setBounds(430,00,250,80);
		panel.add(caja);
	
		
		
		Pop();
		Times();
		fideos();
		cafe();
		
	}
	
	private void botones() {
		uno = new JButton("1");
		uno.setBounds(430,100,60,30);
		panel.add(uno);
		

        dos = new JButton("2");
		dos.setBounds(500,100,60,30);
		panel.add(dos);
		
		tres = new JButton("3");
		tres.setBounds(570,100,60,30);
		panel.add(tres);
		
		cuatro = new JButton("4");
		cuatro.setBounds(640,100,60,30);
		panel.add(cuatro);
		
		popcorn = new JButton("");
		ImageIcon sclim = new ImageIcon("popc.png");
		popcorn.setIcon(new ImageIcon(sclim.getImage().getScaledInstance(32,32, Image.SCALE_SMOOTH)));
		popcorn.setBounds(720,100,60,30);
		panel.add(popcorn);
		
		cinco = new JButton("5");
		cinco.setBounds(430,150,60,30);
		panel.add(cinco);
		
		seis = new JButton("6");
		seis.setBounds(500,150,60,30);
		panel.add(seis);
		
		siete = new JButton("7");
		siete.setBounds(570,150,60,30);
		panel.add(siete);
		
		ocho = new JButton("8");
		ocho.setBounds(640,150,60,30);
		panel.add(ocho);
		
		fideos = new JButton("");
		ImageIcon sclim2 = new ImageIcon("pasta.png");
		fideos.setIcon(new ImageIcon(sclim2.getImage().getScaledInstance(32,32, Image.SCALE_SMOOTH)));
		fideos.setBounds(720,150,60,30);
		panel.add(fideos);
		
		nueve = new JButton("9");
		nueve.setBounds(570,200,60,30);
		panel.add(nueve);
		
		cero = new JButton("0");
		cero.setBounds(640,200,60,30);
		panel.add(cero);
		
		cafe = new JButton("");
		ImageIcon sclim3 = new ImageIcon("coffe.png");
		cafe.setIcon(new ImageIcon(sclim3.getImage().getScaledInstance(32,32, Image.SCALE_SMOOTH)));
		cafe.setBounds(720,200,60,30);
		panel.add(cafe);
		
		borrar = new JButton("reiniciar");
		borrar.setBounds(500,250,100,30);
		panel.add(borrar);
		
		iniciar = new JButton("start");
		iniciar.setBounds(600,250,100,30);
		panel.add(iniciar);
		
		abierto = new JButton("abrir");
		abierto.setBounds(570,300,100,30);
		panel.add(abierto);
		
		cerrar = new JButton("cerrar");
		cerrar.setBounds(650,300,100,30);
		panel.add(cerrar);
		bloquear();
		eventoListener();
		 eventoListener2();
		 eventoListener3();
		 eventoListener4();
		 eventoListener5();
		 eventoListener6();
		 eventoListener7();
		 eventoListener8();
		 eventoListener9();
		 eventoListener0();
		 eventoListenerB();
		 eventoListenerS();
		 eventoListenerP();
		 eventoListenerf();
		 eventoListenerc();
		 eventoListenerabrir();
		 eventoListenercerrar();
	}
	
		
		
	 private void eventoListener() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
					numero1 +="1";
					caja.setText(numero1);
					
					
				
				}
				
			};
			uno.addActionListener(oyente);
		}
	 private void eventoListener2() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="2";
					caja.setText(numero1);
				
				}
				
			};
			dos.addActionListener(oyente);
		}
	 private void eventoListener3() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="3";
					caja.setText(numero1);
				
				}
				
			};
			tres.addActionListener(oyente);
			
			
		}
	 private void eventoListener01() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="1";
					caja2.setText(numero1);
					
				
				}
				
			};
			uno.addActionListener(oyente);
		}
	 private void eventoListener4() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="4";
					caja.setText(numero1);
				
				}
				
			};
			cuatro.addActionListener(oyente);
		}
	 private void eventoListener5() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="5";
					caja.setText(numero1);
				
				}
				
			};
			cinco.addActionListener(oyente);
		}
	 private void eventoListener6() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="6";
					caja.setText(numero1);
				
				}
				
			};
			seis.addActionListener(oyente);
		}
	 private void eventoListener7() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="7";
					caja.setText(numero1);
				
				}
				
			};
			siete.addActionListener(oyente);
		}
	 private void eventoListener8() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="8";
					caja.setText(numero1);
				
				}
				
			};
			ocho.addActionListener(oyente);
		}
	 private void eventoListener9() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="9";
					caja.setText(numero1);
				
				}
				
			};
			nueve.addActionListener(oyente);
		}
	 private void eventoListener0() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1 +="0";
					caja.setText(numero1);
				
				}
				
			};
			cero.addActionListener(oyente);
		}
	 
	 private void eventoListenerB() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				numero1="";
				caja.setText("");
				T.stop();
				f.stop();
				c.stop();
				p.stop();
				
				}
				
			};
			borrar.addActionListener(oyente);
		}
	 
	
	
	 
	 private void Times() {
		
		
		  T=new Timer(1000,new ActionListener () {

			@Override
			public void actionPerformed(ActionEvent e) {
				 try {
						
						i=Integer.parseInt(caja.getText());
						
							
						}catch(NumberFormatException u) {
							
						}
				i--;
				if(i>=0) {
					
					caja.setText("Estara listo en :"  + i);
				}
				if(i<=0) {
					caja.setText("listo");
				}
			}
			 
			 
			 
		 });
				 
				 
				 
				 
				 
		 
	 }
	 public void Pop(){
		 j=30;
		  p=new Timer(1000,new ActionListener () {

			@Override
			public void actionPerformed(ActionEvent y) {
				// TODO Auto-generated method stub
				j--;
				if(j>=0) {
					
					caja.setText("Poporopos listos en : "+j);
				}
				if(j<=0) {
					
					caja.setText("Poporopos listos " );
					
				
				
				}
			}
			 
				
				 
				 
				 
			 });
	 }
	 
	 public void fideos(){
		 k=45;
		  f=new Timer(1000,new ActionListener () {

			@Override
			public void actionPerformed(ActionEvent y) {
				// TODO Auto-generated method stub
				k--;
				if(k>=0) {
					
					caja.setText("fideos listos en : "+k);
				}
				if(k<=0) {
					
					caja.setText("fideos listos ");
				}
			}
			 
				
				 
				 
				 
			 });
	 }
	 public void cafe(){
		 l=25;
		  c=new Timer(1000,new ActionListener () {

			@Override
			public void actionPerformed(ActionEvent y) {
				// TODO Auto-generated method stub
				l--;
				if(l>=0) {
					
					caja.setText("cafe listo en : "+l);
				}
				if(l<=0) {
					
					caja.setText("cafe listo ");
				}
			}
			 
				
				 
				 
				 
			 });
	 }
	 
	 private void eventoListenerS() { // aqui empieza la accion/evento del boton 1
		

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
				T.start();
				
				}
				
			};
			iniciar.addActionListener(oyente);
		}
	 
	 private void eventoListenerP() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
					
				p.start();
				}
				
			};
			popcorn.addActionListener(oyente);
		}
	 private void eventoListenerf() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
					
				f.start();
				}
				
			};
			fideos.addActionListener(oyente);
		}
	 private void eventoListenerc() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
					
				c.start();
				}
				
			};
			cafe.addActionListener(oyente);
		}
	 private void bloquear() {
		 //uno,dos,tres,cuatro,cinco,seis,siete,ocho,nueve,cero,borrar,iniciar,popcorn,cafe,fideos,abierto
		 uno.setEnabled(false);
		 dos.setEnabled(false);
		 tres.setEnabled(false);
		 cuatro.setEnabled(false);
		 cinco.setEnabled(false);
		 seis.setEnabled(false);
		 siete.setEnabled(false);
		 ocho.setEnabled(false);
		 nueve.setEnabled(false);
		 cero.setEnabled(false);
		 borrar.setEnabled(false);
		 iniciar.setEnabled(false);
		 popcorn.setEnabled(false);
		 cafe.setEnabled(false);
		 fideos.setEnabled(false);
		 
		 abierto.setEnabled(true);
	 }
	 private void eventoListenerabrir() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
					uno.setEnabled(true);
					 dos.setEnabled(true);
					 tres.setEnabled(true);
					 cuatro.setEnabled(true);
					 cinco.setEnabled(true);
					 seis.setEnabled(true);
					 siete.setEnabled(true);
					 ocho.setEnabled(true);
					 nueve.setEnabled(true);
					 cero.setEnabled(true);
					 borrar.setEnabled(true);
					 iniciar.setEnabled(true);
					 popcorn.setEnabled(true);
					 cafe.setEnabled(true);
					 fideos.setEnabled(true);
					
				
				}
				
			};
			abierto.addActionListener(oyente);
		}
	 
	 private void eventoListenercerrar() { // aqui empieza la accion/evento del boton 1
			

			ActionListener oyente = new ActionListener( ) {

				@Override
				public void actionPerformed(ActionEvent e) {
					 uno.setEnabled(false);
					 dos.setEnabled(false);
					 tres.setEnabled(false);
					 cuatro.setEnabled(false);
					 cinco.setEnabled(false);
					 seis.setEnabled(false);
					 siete.setEnabled(false);
					 ocho.setEnabled(false);
					 nueve.setEnabled(false);
					 cero.setEnabled(false);
					 borrar.setEnabled(false);
					 iniciar.setEnabled(false);
					 popcorn.setEnabled(false);
					 cafe.setEnabled(false);
					 fideos.setEnabled(false);
					 
					 abierto.setEnabled(true);
				}
				
			};
			cerrar.addActionListener(oyente);
		}
}